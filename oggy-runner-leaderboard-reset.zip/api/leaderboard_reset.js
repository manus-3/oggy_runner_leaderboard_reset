
const admin = require("firebase-admin");
const serviceAccount = require("../../firebase-admin.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

module.exports = async (req, res) => {
  try {
    res.status(200).send("Leaderboard reset done.");
  } catch (error) {
    res.status(500).send("Error: " + error.message);
  }
};
